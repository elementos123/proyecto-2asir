<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <title>Panel de control</title>
</head>
<body>
    <header>
        <p>ControlADY</p>
    </header>
    <center>
    <br><br>
    <nav>
        <ul>
            <li><a href="home.php">Inicio</a></li>
            <li><a href="firewall.php">Firewall</a></li>
            <li><a href="dns.php">DNS</a></li>
            <li><a href="dhcp.php">DHCP</a></li>
        </ul>
        
    </nav>
    <br>
    <hr>
    <br><br><br><br>
    
        <h4>Bienvenido <?php echo $_SESSION["usuario"]; ?> desde aqui puedes acceder a las funciones que te proporcionamos</h4>
    <center>

</body>
</html>